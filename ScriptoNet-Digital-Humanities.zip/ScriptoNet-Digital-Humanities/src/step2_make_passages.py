"""
STEP 2 - Split a novel into passages (the unit our AI will classify).

A "passage" here = 1 to a few paragraphs that together have at least
MIN_WORDS words. Very long paragraphs are cut at sentence ends.

    python src/step2_make_passages.py --name frankenstein --code FRA

Input : data/raw/<name>.txt
Output: data/processed/<name>_passages.csv
        (with empty columns therapeutic / mechanism / intensity / notes,
         ready for annotation later)
"""

import argparse
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"
OUT_DIR = ROOT / "data" / "processed"

MIN_WORDS = 60   # keep merging short paragraphs until a passage reaches this
MAX_WORDS = 300  # split anything longer at sentence boundaries

# A short line counts as a chapter heading if it looks like
# "Chapter 5", "LETTER IV", "Part Two", or "## Something" (from EPUBs)
HEADING = re.compile(
    r"^(##\s+.+|(chapter|letter|part|book|volume)\s+[\w.]+\.?)$", re.IGNORECASE
)


def split_paragraphs(text: str) -> list[str]:
    """Blank lines separate paragraphs. Inside a paragraph, join the wrapped lines."""
    blocks = re.split(r"\n\s*\n", text.replace("\r\n", "\n"))
    paragraphs = []
    for block in blocks:
        para = " ".join(line.strip() for line in block.splitlines()).strip()
        if para:
            paragraphs.append(para)
    return paragraphs


def split_long_paragraph(paragraph: str, max_words: int) -> list[str]:
    """Cut a very long paragraph into chunks at sentence ends."""
    if len(paragraph.split()) <= max_words:
        return [paragraph]
    sentences = re.split(r"(?<=[.!?])\s+", paragraph)
    chunks, current, current_len = [], [], 0
    for sentence in sentences:
        n = len(sentence.split())
        if current and current_len + n > max_words:
            chunks.append(" ".join(current))
            current, current_len = [], 0
        current.append(sentence)
        current_len += n
    if current:
        chunks.append(" ".join(current))
    return chunks


def make_passages(paragraphs: list[str]) -> list[dict]:
    passages = []
    chapter = "Opening"
    buffer, buffer_len = [], 0

    def flush():
        nonlocal buffer, buffer_len
        if buffer:
            passages.append({"chapter": chapter, "text": " ".join(buffer)})
            buffer, buffer_len = [], 0

    for para in paragraphs:
        # Chapter heading? Close the current passage and switch chapter.
        if len(para) < 60 and HEADING.match(para):
            flush()
            chapter = para.lstrip("# ").strip()
            continue

        for piece in split_long_paragraph(para, MAX_WORDS):
            n = len(piece.split())
            if buffer and buffer_len + n > MAX_WORDS:
                flush()  # adding this piece would make the passage too long
            buffer.append(piece)
            buffer_len += n
            if buffer_len >= MIN_WORDS:
                flush()  # passage is big enough - save it

    flush()  # save whatever is left at the end of the book
    return passages


def main():
    parser = argparse.ArgumentParser(description="Split a novel into passages.")
    parser.add_argument("--name", required=True, help="Same name used in Step 1")
    parser.add_argument("--code", required=True, help="3-letter ID code, e.g. FRA, ATN")
    args = parser.parse_args()

    text = (RAW_DIR / f"{args.name}.txt").read_text(encoding="utf-8")
    passages = make_passages(split_paragraphs(text))

    df = pd.DataFrame(passages)
    df.insert(0, "passage_id", [f"{args.code.upper()}-P{i:04d}" for i in range(1, len(df) + 1)])
    df.insert(1, "novel", args.name)
    # position: 0.0 = start of the novel, 1.0 = end (used later for "trajectory maps")
    df["position"] = (df.index / max(len(df) - 1, 1)).round(4)
    df["n_words"] = df["text"].str.split().str.len()
    # Empty columns for annotation later
    for col in ["therapeutic", "mechanism", "intensity", "notes"]:
        df[col] = ""
    df = df[["passage_id", "novel", "chapter", "position", "n_words", "text",
             "therapeutic", "mechanism", "intensity", "notes"]]

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / f"{args.name}_passages.csv"
    df.to_csv(out_path, index=False, encoding="utf-8")

    print(f"Saved {out_path}")
    print(f"Passages : {len(df)}")
    print(f"Chapters : {df['chapter'].nunique()}")
    print(f"Words per passage: mean {df['n_words'].mean():.0f}, "
          f"median {df['n_words'].median():.0f}, "
          f"min {df['n_words'].min()}, max {df['n_words'].max()}")
    print("\nFirst 3 passages:")
    for _, row in df.head(3).iterrows():
        preview = " ".join(row["text"].split()[:25])
        print(f"  {row['passage_id']} [{row['chapter']}] {preview} ...")


if __name__ == "__main__":
    main()
