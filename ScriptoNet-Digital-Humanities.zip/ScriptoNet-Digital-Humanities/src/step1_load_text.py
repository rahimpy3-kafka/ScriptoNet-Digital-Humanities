"""
STEP 1 - Load a novel and save it as clean plain text.

Three ways to get a book in:

  A) Project Gutenberg (free, public-domain books) - best for learning
       python src/step1_load_text.py --gutenberg 84 --name frankenstein

  B) A plain .txt file already on your computer
       python src/step1_load_text.py --txt path/to/book.txt --name mybook

  C) A DRM-free EPUB that you legally own (e.g. a McEwan novel later)
       python src/step1_load_text.py --epub path/to/book.epub --name atonement

Output: data/raw/<name>.txt   (this folder is in .gitignore - never pushed to GitHub)
"""

import argparse
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"


def download_gutenberg(book_id: int) -> str:
    """Download the plain-text version of a Project Gutenberg book."""
    import requests  # imported here so the other options work without it

    url = f"https://www.gutenberg.org/cache/epub/{book_id}/pg{book_id}.txt"
    print(f"Downloading {url} ...")
    response = requests.get(url, timeout=30)
    response.raise_for_status()  # stops with an error if the download failed
    response.encoding = "utf-8"
    return response.text


def strip_gutenberg_boilerplate(text: str) -> str:
    """Gutenberg wraps every book in a licence header and footer. Cut them off."""
    start = re.search(r"\*\*\*\s*START OF (THE|THIS) PROJECT GUTENBERG EBOOK.*?\*\*\*",
                      text, re.IGNORECASE)
    end = re.search(r"\*\*\*\s*END OF (THE|THIS) PROJECT GUTENBERG EBOOK",
                    text, re.IGNORECASE)
    start_idx = start.end() if start else 0
    end_idx = end.start() if end else len(text)
    return text[start_idx:end_idx].strip()


def load_epub(path: str) -> str:
    """
    Read an EPUB in reading order and return its text.
    Headings are written as '## Heading' so Step 2 can detect chapters.
    Note: only works on DRM-free EPUBs.
    """
    from ebooklib import epub
    from bs4 import BeautifulSoup

    book = epub.read_epub(path)
    parts = []
    for item_id, _ in book.spine:  # spine = the book's reading order
        item = book.get_item_with_id(item_id)
        if item is None:
            continue
        soup = BeautifulSoup(item.get_content(), "html.parser")
        for block in soup.find_all(["h1", "h2", "h3", "p"]):
            line = block.get_text(" ", strip=True)
            if not line:
                continue
            if block.name in ("h1", "h2", "h3"):
                line = "## " + line
            parts.append(line)
    # A blank line between blocks = paragraph boundary (Step 2 relies on this)
    return "\n\n".join(parts)


def main():
    parser = argparse.ArgumentParser(description="Load a novel as clean text.")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--gutenberg", type=int, help="Project Gutenberg book ID")
    source.add_argument("--txt", help="Path to a local .txt file")
    source.add_argument("--epub", help="Path to a DRM-free .epub file you own")
    parser.add_argument("--name", required=True, help="Short name, e.g. frankenstein")
    args = parser.parse_args()

    if args.gutenberg:
        text = strip_gutenberg_boilerplate(download_gutenberg(args.gutenberg))
    elif args.txt:
        text = Path(args.txt).read_text(encoding="utf-8")
        text = strip_gutenberg_boilerplate(text)  # harmless if no Gutenberg markers
    else:
        text = load_epub(args.epub)

    RAW_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RAW_DIR / f"{args.name}.txt"
    out_path.write_text(text, encoding="utf-8")

    n_words = len(text.split())
    print(f"Saved {out_path}")
    print(f"Length: {n_words:,} words, {len(text):,} characters")
    print("Tip: open the file and delete any leftover front matter "
          "(contents page, preface, publisher notes) before Step 2.")


if __name__ == "__main__":
    main()
