"""
STEP 3 - A first, deliberately simple "model": keyword matching.

This is NOT the real AI. It's a baseline - the simplest possible method,
so we can later prove a smarter model does better. It counts cue words for
each of the five mechanisms and picks the mechanism with the most hits.

The interesting part is where it FAILS. Read the top passages it finds
and ask: is this really therapeutic, or just a word on the surface?

    python src/step3_keyword_baseline.py --name frankenstein

Input : data/processed/<name>_passages.csv
Output: results/tables/<name>_keyword_baseline.csv   (scores only, no novel text)
        results/figures/<name>_keyword_map.png        (first "trajectory map")
"""

import argparse
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # lets the script save plots without opening a window
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
IN_DIR = ROOT / "data" / "processed"
TABLE_DIR = ROOT / "results" / "tables"
FIG_DIR = ROOT / "results" / "figures"

MIN_HITS = 2  # fewer cue words than this -> predict "none"

# Cue words per mechanism (regex). Edit these and re-run to see what changes!
CUES = {
    "scriptotherapy": [r"writ(e|es|ing|ings|ten)", r"wrote", r"writers?", r"letters?",
                       r"journals?", r"diar(y|ies)", r"drafts?", r"pages?", r"pen",
                       r"ink", r"confess\w*", r"manuscripts?", r"notebooks?"],
    "poetry": [r"poe(m|ms|try|t|ts|tic)", r"verses?", r"stanzas?", r"rhym\w*",
               r"recit\w*", r"ballads?", r"sonnets?"],
    "music": [r"music\w*", r"songs?", r"sang", r"sing(s|ing|er|ers)?", r"melod\w*",
              r"tunes?", r"harmon\w*", r"guitar", r"violin", r"piano", r"cello",
              r"quartet", r"instruments?"],
    "reconstruction": [r"remember\w*", r"recall\w*", r"memor(y|ies)", r"past",
                       r"understood", r"understand\w*", r"reali[sz]\w*", r"meaning",
                       r"stor(y|ies)", r"retold", r"retell\w*"],
    "catharsis": [r"tears?", r"wept", r"weep\w*", r"cr(y|ies|ied|ying)", r"sob\w*",
                  r"relie(f|ved)", r"releas\w*", r"unburden\w*", r"trembl\w*", r"burst"],
}
PATTERNS = {m: re.compile(r"\b(" + "|".join(cues) + r")\b", re.IGNORECASE)
            for m, cues in CUES.items()}
MECHANISMS = list(CUES)


def score_passage(text: str) -> dict:
    """Return hit counts and the matched words for every mechanism."""
    result = {}
    for mech, pattern in PATTERNS.items():
        found = [m.group(0).lower() for m in pattern.finditer(text)]
        result[f"hits_{mech}"] = len(found)
        result[f"words_{mech}"] = ", ".join(sorted(set(found)))
    return result


def main():
    parser = argparse.ArgumentParser(description="Keyword baseline.")
    parser.add_argument("--name", required=True)
    args = parser.parse_args()

    df = pd.read_csv(IN_DIR / f"{args.name}_passages.csv")
    scores = pd.DataFrame([score_passage(t) for t in df["text"]])
    df = pd.concat([df, scores], axis=1)

    # Density = hits per 100 words, so long passages don't win just by being long
    for mech in MECHANISMS:
        df[f"density_{mech}"] = (100 * df[f"hits_{mech}"] / df["n_words"]).round(3)

    hit_cols = [f"hits_{m}" for m in MECHANISMS]
    best = df[hit_cols].idxmax(axis=1).str.replace("hits_", "", regex=False)
    df["predicted"] = best.where(df[hit_cols].max(axis=1) >= MIN_HITS, "none")

    # --- Save a table WITHOUT the novel text (safe to push to GitHub) ---
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    keep = ["passage_id", "chapter", "position", "n_words", "predicted"] + \
           hit_cols + [f"words_{m}" for m in MECHANISMS]
    out_table = TABLE_DIR / f"{args.name}_keyword_baseline.csv"
    df[keep].to_csv(out_table, index=False)

    # --- Print a summary ---
    print(f"Passages analysed: {len(df)}\n")
    print("Predicted labels:")
    print(df["predicted"].value_counts().to_string(), "\n")

    print("Top 3 passages per mechanism (read these and judge them yourself!):")
    for mech in MECHANISMS:
        top = df.sort_values(f"hits_{mech}", ascending=False).head(3)
        print(f"\n=== {mech.upper()} ===")
        for _, row in top.iterrows():
            if row[f"hits_{mech}"] == 0:
                continue
            preview = " ".join(row["text"].split()[:30])
            print(f"  {row['passage_id']} [{row['chapter']}] hits={row[f'hits_{mech}']} "
                  f"cues=({row[f'words_{mech}']})")
            print(f"    {preview} ...")

    # --- First trajectory map: cue density across the novel ---
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    window = max(5, len(df) // 30)  # smoothing window (in passages)
    fig, ax = plt.subplots(figsize=(11, 5))
    for mech in MECHANISMS:
        smooth = df[f"density_{mech}"].rolling(window, center=True, min_periods=1).mean()
        ax.plot(df["position"], smooth, label=mech, linewidth=2)
    ax.set_xlabel("Narrative position (0 = start, 1 = end)")
    ax.set_ylabel("Cue words per 100 words (smoothed)")
    ax.set_title(f"Keyword-baseline map: {args.name}")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    out_fig = FIG_DIR / f"{args.name}_keyword_map.png"
    fig.savefig(out_fig, dpi=150)

    print(f"\nSaved {out_table}")
    print(f"Saved {out_fig}")


if __name__ == "__main__":
    main()
