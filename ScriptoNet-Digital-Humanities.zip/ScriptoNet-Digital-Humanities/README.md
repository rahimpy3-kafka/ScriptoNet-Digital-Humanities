# ScriptoNet: AI-Assisted Mapping of Therapeutic Processes in Literary Fiction

> 🚧 Early-stage, exploratory project. No trained model yet. Everything here is a work in progress.

## About

<!-- ✍️ Write this section yourself, in your own words (3–5 sentences):
     - What question are you exploring?
     - Why combine literature and AI?
     - What does the AI do, and what stays with the human reader? -->

## Five mechanisms (working definitions, to be refined with a literary expert)

| Mechanism | Working idea |
|---|---|
| Scriptotherapy | Writing / rewriting used to process a difficult experience |
| Poetry-mediated processing | Poetry used for emotional expression or insight |
| Music-mediated processing | Music as a pathway to emotion or memory |
| Narrative reconstruction | A character reinterprets their past or themselves |
| Emotional catharsis | Release of previously held-in emotion |

## Progress

- [x] Step 1 – Load a novel as clean text
- [x] Step 2 – Split it into passages
- [x] Step 3 – Keyword baseline (a deliberately naive first "model")
- [ ] Step 4 – Zero-shot LLM classifier
- [ ] Step 5 – Compare against passages discussed in published scholarship
- [ ] Later (with expert annotation) – trained models, explainability, more novels

## How to run

```bash
pip install -r requirements.txt

# Step 1: get a book (Frankenstein = Project Gutenberg ID 84)
python src/step1_load_text.py --gutenberg 84 --name frankenstein

# Step 2: split into passages
python src/step2_make_passages.py --name frankenstein --code FRA

# Step 3: run the keyword baseline
python src/step3_keyword_baseline.py --name frankenstein
```

Other good practice books: *The Yellow Wallpaper* (ID 1952), a story told through a private journal.

**Google Colab:** start each command with `!`, and first run
`!git clone https://github.com/<your-username>/ScriptoNet-Digital-Humanities.git` then
`%cd ScriptoNet-Digital-Humanities`.

## Repository structure

```
ScriptoNet-Digital-Humanities/
├── src/
│   ├── step1_load_text.py        # Gutenberg / txt / EPUB -> data/raw/<name>.txt
│   ├── step2_make_passages.py    # text -> data/processed/<name>_passages.csv
│   └── step3_keyword_baseline.py # passages -> results/ (scores + map)
├── data/                         # novel text lives here, NOT pushed (see data/README.md)
└── results/
    ├── tables/                   # scores only, no novel text
    └── figures/
```

## Copyright

Copyrighted novels are never uploaded here. `data/raw/` and `data/processed/` are
in `.gitignore`. Only IDs, labels, scores and figures are shared.

## Author

Rupa <!-- add your college / LinkedIn -->
