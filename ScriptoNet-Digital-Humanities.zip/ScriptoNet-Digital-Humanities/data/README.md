# Data folder

| Folder | What goes in it | Pushed to GitHub? |
|---|---|---|
| `data/raw/` | Full novel text from Step 1 | **No** (in `.gitignore`) |
| `data/processed/` | Passage CSVs from Step 2 (contain novel text) | **No** (in `.gitignore`) |

Both folders are created automatically when you run the scripts.

**Copyright rule:** novels like Ian McEwan's are in copyright. Their text stays on
your computer only. What *can* be shared: passage IDs, chapter names, positions,
labels, scores, and figures (everything in `results/`).

Public-domain books from Project Gutenberg are free to use, but we keep the same
habit for every book so nothing slips through by mistake.
